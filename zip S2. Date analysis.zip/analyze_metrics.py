# coding=utf-8
from scipy.stats import beta
from sklearn.metrics import f1_score
import pandas as pd
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--sample_result', type=str, required=True, help='样本结果')
args = parser.parse_args()
sample_result = args.sample_result

# 读取文件
df = pd.read_csv(sample_result)

# 总样本数
n = len(df)

# 混淆矩阵元素
TP = ((df["real"] == 1) & (df["pred"] == 1)).sum()
FN = ((df["real"] == 1) & (df["pred"] == 0)).sum()
TN = ((df["real"] == 0) & (df["pred"] == 0)).sum()
FP = ((df["real"] == 0) & (df["pred"] == 1)).sum()

print("n =", n)
print("TP =", TP)
print("FN =", FN)
print("TN =", TN)
print("FP =", FP)

# 计算指标
accuracy = (TP + TN) / n
sensitivity = TP / (TP + FN)  # 灵敏度 Sensitivity (召回率)
specificity = TN / (TN + FP)  # 特异性 Specificity
PPV = TP / (TP + FP) if (TP + FP) > 0 else 0  # 阳性预测值 Positive Predictive Value
NPV = TN / (TN + FN) if (TN + FN) > 0 else 0  # 阴性预测值 Negative Predictive Value
f1 = f1_score( [1] * (TP + FN) + [0] * (FP + TN),[1] * TP + [0] * FN + [1] * FP + [0] * TN)  # F1 Score

alpha = 0.05  # 95% 置信水平

# 计算 95% 置信区间 (Clopper-Pearson 方法)
def compute_ci(successes, total):
    lower = beta.ppf(alpha / 2, successes, total - successes + 1)
    upper = beta.ppf(1 - alpha / 2, successes + 1, total - successes)
    return (lower, upper)

accuracy_ci = compute_ci(TP + TN, n)
sensitivity_ci = compute_ci(TP, TP + FN)
specificity_ci = compute_ci(TN, TN + FP)
PPV_ci = compute_ci(TP, TP + FP) if (TP + FP) > 0 else (0, 0)
NPV_ci = compute_ci(TN, TN + FN) if (TN + FN) > 0 else (0, 0)
f1_ci = compute_ci(int(f1 * n), n)  # 近似计算 F1 Score 的置信区间


# 输出结果
results = {
    "Accuracy": (accuracy, accuracy_ci),
    "Sensitivity": (sensitivity, sensitivity_ci),
    "Specificity": (specificity, specificity_ci),
    "PPV": (PPV, PPV_ci),
    "NPV": (NPV, NPV_ci),
    "F1 Score": (f1, f1_ci),
}

for metric, (value, ci) in results.items():
    print(f"{metric}: {value:.3f}({ci[0]:.3f} to {ci[1]:.3f})")
