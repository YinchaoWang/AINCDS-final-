import argparse
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc, precision_recall_curve, f1_score, average_precision_score
from scipy.stats import beta

# 解析命令行参数
parser = argparse.ArgumentParser(description="Plot ROC, PR, and Sensitivity-Specificity curves with 95% CI for internal and external validation results.")
parser.add_argument('--internal_result', type=str, required=True, help="内部验证样本结果 CSV 文件路径")
parser.add_argument('--external_result', type=str, required=True, help="外部验证样本结果 CSV 文件路径")
args = parser.parse_args()

file1 = args.internal_result
file2 = args.external_result

# 确保列名正确
score_col = "score"  # 模型预测的概率分数
pred_col = "pred"  # 预测类别（0/1）
true_col = "real"  # 真实类别（0/1）
df1 = pd.read_csv(file1)
df2 = pd.read_csv(file2)

# 读取数据
def get_data(df):
    return df[true_col].values, df[score_col].values, df[pred_col].values

y_true_int, y_scores_int, y_pred_int = get_data(df1)
y_true_ext, y_scores_ext, y_pred_ext = get_data(df2)

# 计算 ROC 曲线 和 AUC
fpr_int, tpr_int, _ = roc_curve(y_true_int, y_scores_int)
fpr_ext, tpr_ext, _ = roc_curve(y_true_ext, y_scores_ext)
roc_auc_int = auc(fpr_int, tpr_int)
roc_auc_ext = auc(fpr_ext, tpr_ext)

# 计算 PR 曲线 和 AUC
precision_int, recall_int, _ = precision_recall_curve(y_true_int, y_scores_int)
precision_ext, recall_ext, _ = precision_recall_curve(y_true_ext, y_scores_ext)
pr_auc_int = average_precision_score(y_true_int, y_scores_int)
pr_auc_ext = average_precision_score(y_true_ext, y_scores_ext)

# 计算 F1 分数
f1_int = f1_score(y_true_int, y_pred_int)
f1_ext = f1_score(y_true_ext, y_pred_ext)

# 计算 灵敏度-特异性曲线
specificity_int = 1 - fpr_int
specificity_ext = 1 - fpr_ext
sensitivity_specificity_auc_int = auc(specificity_int, tpr_int)
sensitivity_specificity_auc_ext = auc(specificity_ext, tpr_ext)

# 计算 95% 置信区间
alpha = 0.05  # 95% 置信区间

def compute_ci(successes, total):
    lower = beta.ppf(alpha / 2, successes, total - successes + 1)
    upper = beta.ppf(1 - alpha / 2, successes + 1, total - successes)
    return (lower, upper)

# 计算 AUC 置信区间
def calculate_auc_ci(fpr, tpr, y_true, y_pred):
    # 计算 True Positive 数量（成功的样本数）
    successes = np.cumsum(y_true == 1)
    total = np.arange(1, len(y_true) + 1)  # 总数
    lower, upper = compute_ci(successes, total)
    return lower[-1], upper[-1]

# 计算 ROC 曲线的 AUC 置信区间
roc_auc_int_lower, roc_auc_int_upper = calculate_auc_ci(fpr_int, tpr_int, y_true_int, y_pred_int)
roc_auc_ext_lower, roc_auc_ext_upper = calculate_auc_ci(fpr_ext, tpr_ext, y_true_ext, y_pred_ext)

# 计算 PR 曲线的 AUC 置信区间
pr_auc_int_lower, pr_auc_int_upper = calculate_auc_ci(recall_int, precision_int, y_true_int, y_pred_int)
pr_auc_ext_lower, pr_auc_ext_upper = calculate_auc_ci(recall_ext, precision_ext, y_true_ext, y_pred_ext)

# 计算 灵敏度-特异性曲线的 AUC 置信区间
sensitivity_specificity_auc_int_lower, sensitivity_specificity_auc_int_upper = calculate_auc_ci(specificity_int, tpr_int, y_true_int, y_pred_int)
sensitivity_specificity_auc_ext_lower, sensitivity_specificity_auc_ext_upper = calculate_auc_ci(specificity_ext, tpr_ext, y_true_ext, y_pred_ext)

# 绘制 ROC 曲线
plt.figure(figsize=(6,6))
plt.plot(fpr_int, tpr_int, color='blue', lw=2, label=f'Internal Validation AUC = {roc_auc_int:.3f} ({roc_auc_int_lower:.3f}-{roc_auc_int_upper:.3f})')
plt.plot(fpr_ext, tpr_ext, color='red', lw=2, label=f'External Validation AUC = {roc_auc_ext:.3f} ({roc_auc_ext_lower:.3f}-{roc_auc_ext_upper:.3f})')
plt.plot([0, 1], [0, 1], color='gray', linestyle='--')  # 参考线
plt.xlabel('False Positive Rate (FPR)')
plt.ylabel('True Positive Rate (TPR)')
plt.title('ROC Curve')
plt.legend(loc="lower right")
plt.show()

# 绘制 PR 曲线
plt.figure(figsize=(6,6))
plt.plot(recall_int, precision_int, color='blue', lw=2, label=f'Internal Validation AUC = {pr_auc_int:.3f} ({pr_auc_int_lower:.3f}-{pr_auc_int_upper:.3f})')
plt.plot(recall_ext, precision_ext, color='red', lw=2, label=f'External Validation AUC = {pr_auc_ext:.3f} ({pr_auc_ext_lower:.3f}-{pr_auc_ext_upper:.3f})')
plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('Precision-Recall Curve')
plt.legend(loc="lower left")  # 位置修改为左下角
plt.show()

# 绘制 灵敏度-特异性曲线
plt.figure(figsize=(6,6))
plt.plot(specificity_int, tpr_int, color='blue', lw=2, label=f'Internal Validation AUC = {sensitivity_specificity_auc_int:.3f} ({sensitivity_specificity_auc_int_lower:.3f}-{sensitivity_specificity_auc_int_upper:.3f})')
plt.plot(specificity_ext, tpr_ext, color='red', lw=2, label=f'External Validation AUC = {sensitivity_specificity_auc_ext:.3f} ({sensitivity_specificity_auc_ext_lower:.3f}-{sensitivity_specificity_auc_ext_upper:.3f})')
plt.xlabel('Specificity')
plt.ylabel('Sensitivity')
plt.title('Sensitivity-Specificity Curve')
plt.legend(loc="lower left")  # 位置修改为左下角
plt.show()

# 输出 F1 分数
print(f'Internal Validation F1 Score: {f1_int:.4f}')
print(f'External Validation F1 Score: {f1_ext:.4f}')