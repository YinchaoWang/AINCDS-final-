#coding=utf-8

import numpy as np


def jaccard_overall(preds, targs):
    n = preds.shape[0]
    preds = preds.view(n, -1)
    targs = targs.view(n, -1)
    intersect = (preds * targs).sum(-1).float()
    union = ((preds+targs)>0).sum(-1).float()
    u0 = union==0
    intersect[u0] = 1
    union[u0] = 2
    return (intersect / union)


def calc_jaccard(gt_seg, pred_seg):

    nom = np.sum(gt_seg * pred_seg)
    denom = np.sum((gt_seg+pred_seg)>0)

    dice = float(nom) / float(denom)
    return dice


def calc_jaccard_all(preds_m, ys):
    dice_all = 0
    for i in range(preds_m.shape[0]):
        pred = preds_m[i,0,:,:]
        gt = ys[i,0,:,:]
#         print(np.sum(pred))
        if np.sum(gt) == 0 and np.sum(pred) == 0:
            dice_all = dice_all + 1
        elif np.sum(gt) == 0 and np.sum(pred) != 0:
            dice_all = dice_all
        else:
            dice_all = dice_all + calc_jaccard(gt, pred)
    return dice_all/preds_m.shape[0]