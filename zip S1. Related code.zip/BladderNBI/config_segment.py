#coding=utf-8
import os
from utils import mkdir_with_check
class BaseConfig():
    def __init__(self,base_dir):

        # self.set_path(dataset_type='official')
        self.sample_submit_file = ""
        self.weights = base_dir + "/models"
        self.best_models = base_dir + "/best_models/"
        self.submit = base_dir + "/submit/"
        self.logs_dir = base_dir + '/logs'
        self.features_dir = base_dir + '/features'
        self.swa_dir = base_dir + '/swa'
        self.workers = 10
        self.epochs = 50
        mkdir_with_check(base_dir)
        mkdir_with_check(self.weights)
        mkdir_with_check(self.best_models)
        mkdir_with_check(self.submit)
        mkdir_with_check(self.logs_dir)
        mkdir_with_check(self.features_dir)
        mkdir_with_check(self.swa_dir)
        self.ACTIVATION = None#'sigmoid'
        self.CLASSES = 1
        self.in_channels=3
        self.decoder_channels=(256, 128, 64, 32, 16)
