VERSION = (0, 4, 1, "dev0")

__version__ = ".".join(map(str, VERSION))
