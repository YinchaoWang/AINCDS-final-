from .model import UPerNet

__all__ = ["UPerNet"]
