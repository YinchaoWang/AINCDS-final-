from .oxford_pet import OxfordPetDataset, SimpleOxfordPetDataset

__all__ = ["OxfordPetDataset", "SimpleOxfordPetDataset"]
