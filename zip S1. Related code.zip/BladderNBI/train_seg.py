#coding=utf-8

import argparse
import csv
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "2"
import sys
import time

import cv2
import pandas as pd
import torch
import torch.backends.cudnn as cudnn
import torch.nn.functional as F
import tqdm


torch.backends.cudnn.benchmark = True
cudnn.deterministic = False
USE_APEX = False

if USE_APEX:
    import apex
USE_TENSORBOARD = True
if USE_TENSORBOARD:
    try:
        from tensorboardX import SummaryWriter
    except:
        USE_TENSORBOARD = False

from utils import init_random_seed,WarmRestart,warm_restart
from data.dataset import generate_dataset_loader
from data.transformer import load_transformer
from losses.get_loss import MutilLoss
from config_segment import BaseConfig
from torch.optim import lr_scheduler
from metrics.dice_score import *
init_random_seed()


import segmentation_models_pytorch as smp

def get_net(config):

    model = smp.FPN(
            encoder_name=config.ENCODER,
            classes=config.CLASSES,
            in_channels=config.in_channels,
        )

    return model


def epochVal(model, dataLoader, loss_seg):
    model.cuda()
    model.eval()
    lossVal = 0
    lossValNorm = 0
    valLoss_seg = 0

    outGT = []
    outPRED = []
    # metric_iou = smp.utils.metrics.IoU()
    pBar = tqdm.tqdm(total=len(dataLoader))
    with torch.no_grad():
        for i, (input, target_seg) in enumerate(dataLoader):

            varInput = torch.autograd.Variable(input).cuda()
            varTarget_seg = target_seg.contiguous().cuda()

            outGT.append(varTarget_seg.data.cpu().float())
            varOutput_seg = model(varInput)
            varTarget_seg = varTarget_seg.float()
            lossvalue_seg = loss_seg(varOutput_seg, varTarget_seg)
            valLoss_seg = valLoss_seg + lossvalue_seg.item()

            varOutput_seg = varOutput_seg.sigmoid()
            # iou = metric_iou(varOutput_seg,varTarget_seg)
            # print (iou.data.cpu().float())
            outPRED.append(varOutput_seg.data.cpu().float())
            lossValNorm += 1
            if i%10==0:
                pBar.update(10)
    pBar.close()
    valLoss_seg = valLoss_seg / lossValNorm

    predsr_with_no_mask = F.upsample(torch.cat(outPRED), size=(128, 128), mode='bilinear').numpy()
    ysr_with_no_mask = F.upsample(torch.cat(outGT), size=(128, 128), mode='bilinear').numpy()
    dicesr_with_no_mask = []
    thrs = np.arange(0.0, 0.9, 0.05)
    best_dicer_with_no_mask = 0
    best_thrr_with_no_mask = 0

    for i in thrs:
        preds_mr_with_no_mask = (predsr_with_no_mask > i)
        a = calc_dice_all(preds_mr_with_no_mask, ysr_with_no_mask)
        dicesr_with_no_mask.append(a)
    dicesr_with_no_mask = np.array(dicesr_with_no_mask)
    best_dicer_with_no_mask = dicesr_with_no_mask.max()
    best_thrr_with_no_mask = thrs[dicesr_with_no_mask.argmax()]

    index = np.sum(np.reshape(ysr_with_no_mask, (ysr_with_no_mask.shape[0], -1)), 1)
    predsr_without_no_mask = predsr_with_no_mask[index != 0, :, :, :]
    ysr_without_no_mask = ysr_with_no_mask[index != 0, :, :, :]

    dicesr_without_no_mask = []
    thrs = np.arange(0.0, 0.9, 0.05)
    best_dicer_without_no_mask = 0
    best_thrr_without_no_mask = 0

    for i in thrs:
        preds_mr_without_no_mask = (predsr_without_no_mask > i)
        a = calc_dice_all(preds_mr_without_no_mask, ysr_without_no_mask)
        dicesr_without_no_mask.append(a)
    dicesr_without_no_mask = np.array(dicesr_without_no_mask)

    best_dicer_without_no_mask = dicesr_without_no_mask.max()
    best_thrr_without_no_mask = thrs[dicesr_without_no_mask.argmax()]

    for it in range(10):
        cv2.imwrite('data/tmp/{}_pred.png'.format(it),(preds_mr_without_no_mask[it,0]*255).astype(np.uint8))
        cv2.imwrite('data/tmp/{}_gt.png'.format(it),(ysr_without_no_mask[it,0]*255).astype(np.uint8))

    return valLoss_seg, best_thrr_with_no_mask, best_dicer_with_no_mask, best_thrr_without_no_mask, best_dicer_without_no_mask



def dotrain(fold,config):
    # halfmode = False

    train_transformer,val_transformer = load_transformer(config.image_size)
    df_train = pd.read_csv('/fdata/lichuanpeng/Research/PangGuangJing/training_files/seg_dataset/train_fold{}.csv'.format(fold))
    df_val = pd.read_csv('/fdata/lichuanpeng/Research/PangGuangJing/training_files/seg_dataset/val_fold{}.csv'.format(fold))

    train_loader, valid_loader = generate_dataset_loader(df_train,train_transformer,config.batch_size,df_val,val_transformer,config.batch_size,config.workers)

    model = get_net(config)
    epoch_start=0
    if args.pretrained != '':
        if not os.path.exists(args.pretrained):
            print(args.pretrained, 'not exists')
            sys.exit(0)
        print("load model, continue training...")
        checkpoint = torch.load(args.pretrained)
        epoch_start = checkpoint['epoch']
        model.load_state_dict(checkpoint['state_dict'])


    if USE_APEX:
        model = apex.parallel.convert_syncbn_model(model).cuda()

    if args.swa:
        optimizer = torch.optim.SGD(model.parameters(),lr=config.learn_rate,weight_decay=1e-4,)
    else:
        optimizer = torch.optim.Adam(model.parameters(), lr=config.learn_rate, betas=(0.9, 0.999), eps=1e-08,
                                     weight_decay=1e-4)

    if config.lr_scheduler == 'step':
        print('>>>>>>[LR]-->StepLR')
        scheduler = lr_scheduler.StepLR(optimizer , step_size=15,gamma=0.5)
    elif config.lr_scheduler == 'exp':
        print('>>>>>>[LR]-->ExponentialLR')
        import math
        scheduler = lr_scheduler.ExponentialLR(optimizer,gamma=math.exp(-0.02))
    elif config.lr_scheduler == 'mstep':
        print('>>>>>>[LR]-->ExponentialLR')
        scheduler = lr_scheduler.MultiStepLR(optimizer,
                                             milestones=[int(_) for _ in config.lr_mstep_milestones.split(',')],
                                             gamma=args.lr_gamma,last_epoch=epoch_start)
    elif config.lr_scheduler == 'warmrestart':
        scheduler = WarmRestart(optimizer, T_max=10, T_mult=1, eta_min=1e-6)

    if config.multi_gpu:
        model = torch.nn.DataParallel(model)
    loss_seg = MutilLoss({'CrossEntropyLoss':0.2,'DiceLoss':0.8})
    # loss_seg = MutilLoss({'GDiceLossV2':1})


    trMaxEpoch = 100
    lossMIN = 100000
    val_dice_max = 0

    for epochID in range(0, trMaxEpoch):

        start_time = time.time()
        model.cuda()
        model.train()
        trainLoss = 30
        lossTrainNorm = 0
        trainLoss_cls = 0
        trainLoss_seg = 0
        if not args.swa:
            if epochID < 40:
                if epochID != 0:
                    scheduler.step()
                    if config.lr_scheduler == 'warmrestart':
                        scheduler = warm_restart(scheduler, T_mult=2)
            elif epochID > 39 and epochID < 42:
                optimizer.param_groups[0]['lr'] = 1e-5
            else:
                optimizer.param_groups[0]['lr'] = 5e-6
        pBar = tqdm.tqdm(total=len(train_loader))
        for batchID, (input, target_seg) in enumerate(train_loader):
            # if batchID>50:
            #     pBar.close()
            #     break
            if batchID==0:
                ss_time=time.time()
            varInput = torch.autograd.Variable(input).cuda()
            varTarget_seg = target_seg.contiguous().cuda()

            varOutput_seg = model(varInput)
            varTarget_seg = varTarget_seg.float()

            lossvalue_seg = loss_seg(varOutput_seg, varTarget_seg)
            trainLoss_seg = trainLoss_seg + lossvalue_seg.item()


            lossvalue = lossvalue_seg
            lossTrainNorm = lossTrainNorm + 1
            optimizer.zero_grad()

            lossvalue.backward()

            optimizer.step()
            # print(str(batchID) + '/' + str(len(train_loader)) + '     ' + str(
            #     (time.time() - ss_time) / (batchID + 1)), end='\r')
            if batchID%10==0:
                pBar.update(10)
        pBar.close()

        trainLoss_seg = trainLoss_seg / lossTrainNorm
        trainLoss = trainLoss_seg

        best_thr_with_no_mask = -1
        best_dice_with_no_mask = -1
        best_thr_without_no_mask = -1
        best_dice_without_no_mask = -1
        valLoss_seg = -1

        if epochID % 1 == 0:
            valLoss_seg, best_thr_with_no_mask, best_dice_with_no_mask, best_thr_without_no_mask, best_dice_without_no_mask = epochVal(
                model, valid_loader, loss_seg)  # (model, dataLoader, loss_seg, c_val, val_batch_size):

        epoch_time = time.time() - start_time

        if epochID % 1 == 0:
            torch.save({'epoch': epochID + 1, 'state_dict': model.state_dict(), 'valLoss': 0,
                        'best_thr_with_no_mask': best_thr_with_no_mask,
                        'best_dice_with_no_mask': float(best_dice_with_no_mask),
                        'best_thr_without_no_mask': best_thr_without_no_mask,
                        'best_dice_without_no_mask': float(best_dice_without_no_mask)},
                       config.weights + '/model_epoch_' + str(epochID) + '_fold_' + str(fold) + '.pth.tar')

        result = [epochID, round(optimizer.state_dict()['param_groups'][0]['lr'], 6), round(epoch_time, 0),
                  round(trainLoss, 4), round(valLoss_seg, 4), round(best_thr_with_no_mask, 3),
                  round(float(best_dice_with_no_mask), 3), round(best_thr_without_no_mask, 3),
                  round(float(best_dice_without_no_mask), 3)]
        summary_writer.add_scalar('lr/fold{}'.format(fold), optimizer.state_dict()['param_groups'][0]['lr'], epochID)
        summary_writer.add_scalar('train/fold{}-loss'.format(fold), trainLoss, epochID)
        summary_writer.add_scalar('val/fold{}-loss'.format(fold), valLoss_seg, epochID)
        summary_writer.add_scalar('val/fold{}-best_dice_with_no_mask'.format(fold), best_dice_with_no_mask, epochID)
        summary_writer.add_scalar('val/fold{}-best_dice_without_no_mask'.format(fold), best_dice_without_no_mask, epochID)

        print(result)
        with open(config.logs_dir + '/log.csv', 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(result)
    if args.swa:
        optimizer.swap_swa_sgd()

        torch.save({'epoch': epochID + 1, 'state_dict': model.state_dict()},
                   config.weights + '/model_epoch_least_fold_' + str(fold) + '.pth.tar')

    del model


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    parser.add_argument("-p", "--pretrained", type=str, default='', help='continue to train from pretrained model')
    parser.add_argument("-bs", "--batch-size", type=int, default=4, help='batch size')
    parser.add_argument('-g', "--gpu", type=str, default='1', help='gpu number')
    parser.add_argument("-en", "--encoder-name", type=str, default='', help='encoder name')
    # parser.add_argument("-ew", "--encoder-weights", type=str, default='imagenet', help='encoder weights')
    parser.add_argument("-lr", "--learning-rate", type=float, default=5e-4, help='learning rate')
    parser.add_argument("-lrs", "--lr-scheduler", type=str, default='warmrestart', choices=['warmrestart','step', 'exp','mstep'],help='learning rate scheduler' )
    parser.add_argument("-size", "--image-size", type=int, default=512, help='model input width')
    parser.add_argument("-f", "--fold", type=int, default=0, help='fold')
    parser.add_argument("-t", "--tag", type=str, default='', help='dir name')
    parser.add_argument("-arc", "--architectures", type=str, default='Unet', help='architectures name', choices=['Unet','Linknet','FPN','PSPNet','Xnet','R2AttU_Net','R2U_Net','AttU_Net','BCDU_net','DeepSRNX50V3PlusD_m1','DeepR50V3PlusD_m1','X_Unet'])
    parser.add_argument('-swa',"--swa",action="store_true",default=False)

    args = parser.parse_args()
    config = BaseConfig('/data/lichuanpeng/Research/PangGuangJing/Models/seg_2d/{}/{}'.format(args.encoder_name,args.tag))


    config.ENCODER = args.encoder_name
    # config.ENCODER_WEIGHTS = args.encoder_weights
    config.ENCODER_WEIGHTS = None
    config.ARCHITECTURES = args.architectures
    config.learn_rate = args.learning_rate
    config.lr_scheduler = args.lr_scheduler

    if args.gpu.find(',') >= 0:
        config.multi_gpu=True
        device_ids = [int(id) for id in args.gpu.split(',')]
        DEVICE = 'cuda:'+str(device_ids[0])
    else:
        config.multi_gpu=False
        os.environ['CUDA_VISIBLE_DEVICES'] = str(args.gpu)
        device_ids = [int(args.gpu)]
        DEVICE = 'cuda'
        print ('set cuda:',str(args.gpu))

    config.batch_size = args.batch_size
    config.learning_rate = args.learning_rate
    config.image_size = args.image_size
    fold = args.fold

    if USE_TENSORBOARD:
        summary_writer = SummaryWriter(config.logs_dir)

    dotrain(fold,config)
