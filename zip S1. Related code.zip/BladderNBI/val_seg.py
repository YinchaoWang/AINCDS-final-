#coding=utf-8
import torch
import pandas as pd
import tqdm
import numpy as np
import os
from data.dataset import generate_val_dataloader
from data.transformer import load_transformer
from config_segment import BaseConfig
import argparse
import cv2
from utils.base import mkdir_with_check
from metrics.dice_score import *
from metrics.jaccard_score import *


def save_fig_with_check_dir(save_path, img):
    mkdir_with_check(os.path.dirname(save_path))
    cv2.imwrite(save_path,img)
    print ('fig saved to ',save_path)

import segmentation_models_pytorch as smp

def get_net(config):

    model = smp.FPN(
            encoder_name=config.ENCODER,
            classes=config.CLASSES,
            in_channels=config.in_channels,
        )

    return model

if __name__ == '__main__':

    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    parser.add_argument("-p", "--pretrained", type=str, default='', help='continue to train from pretrained model')
    parser.add_argument("-bs", "--batch-size", type=int, default=4, help='batch size')
    parser.add_argument('-g', "--gpu", type=str, default='1', help='gpu number')
    parser.add_argument("-en", "--encoder-name", type=str, default='', help='encoder name')
    parser.add_argument("-size", "--image-size", type=int, default=512, help='model input width')
    parser.add_argument("-f", "--fold", type=int, default=0, help='fold')
    parser.add_argument("-t", "--tag", type=str, default='', help='dir name')
    parser.add_argument("-arc", "--architectures", type=str, default='Unet', help='architectures name' )
    parser.add_argument("-fig", "--save_fig", action='store_true', help='is save seg figure')
    parser.add_argument("-tta",'--test_time_augment', type=str,default='',choices=['','flip'])


    args = parser.parse_args()
    config = BaseConfig(
        '/data/lichuanpeng/Research/PangGuangJing/Models/seg_2d/{}/{}'.format(args.encoder_name, args.tag))

    config.ENCODER = args.encoder_name
    # config.ENCODER_WEIGHTS = args.encoder_weights
    config.ENCODER_WEIGHTS = None
    config.ARCHITECTURES = args.architectures
    os.environ['CUDA_VISIBLE_DEVICES'] = str(args.gpu)
    config.batch_size = args.batch_size
    config.image_size = args.image_size
    fold = args.fold

    _, val_transformer = load_transformer(config.image_size)
    df_val = pd.read_csv('/fdata/lichuanpeng/Research/PangGuangJing/training_files/seg_dataset/test.csv')
    data_loader = generate_val_dataloader(df_val,val_transformer,val_batch_size=config.batch_size,workers=5,tta_type=args.test_time_augment if args.test_time_augment!='' else None)


    model = get_net(config)
    # model = torch.nn.DataParallel(model)
    try:
        model.load_state_dict(torch.load(os.path.join(config.weights,args.pretrained))['state_dict'])
    except:
        model = torch.nn.DataParallel(model)
        model.load_state_dict(torch.load(os.path.join(config.weights,args.pretrained))['state_dict'])


    model.cuda()
    pBar = tqdm.tqdm(total=len(data_loader))
    start_index = 0
    thresholds = list(np.linspace(0,1,num=21))

    dice_score_all = [0 for _ in range(len(thresholds))]
    jaccard_score_all = [0 for _ in range(len(thresholds))]
    dice_score_without_nomask = [0 for _ in range(len(thresholds))]
    jaccard_score_without_nomask  = [0 for _ in range(len(thresholds))]
    without_nomask_count=  0
    with torch.no_grad():
        for i, (input, target_seg) in enumerate(data_loader):
            input_size = input.size()
            sub_image_num_pre_Imaage = 1
            if len(input_size) == 5:
                bs, sub_image_num_pre_Imaage, c, h, w = input_size
                input = input.view(-1, c, h, w)
            varInput = torch.autograd.Variable(input).cuda()
            varOutput_seg = model(varInput).sigmoid().data.cpu().float().numpy()
            if sub_image_num_pre_Imaage != 1:
                # print (varOutput_seg.shape[0] / sub_image_num_pre_Imaage, sub_image_num_pre_Imaage, varOutput_seg.shape[1], varOutput_seg.shape[2], varOutput_seg.shape[3])
                varOutput_seg = np.reshape(varOutput_seg, (varOutput_seg.shape[0] // sub_image_num_pre_Imaage, sub_image_num_pre_Imaage, varOutput_seg.shape[1], varOutput_seg.shape[2], varOutput_seg.shape[3]))
                if args.test_time_augment == 'flip':
                    for _it in range(varOutput_seg.shape[0]):
                        varOutput_seg[_it,1,0] = np.fliplr(varOutput_seg[_it,1,0])
                # print (varOutput_seg.shape)
                varOutput_seg = np.average(varOutput_seg, axis=1)


            target_seg = target_seg.data.float().numpy()
            if i % 10 == 0:
                pBar.update(10)
            # index = np.sum(np.reshape(target_seg, (target_seg.shape[0], -1)), 1)
            # predsr_without_no_mask = target_seg[index != 0, :, :, :]
            # ysr_without_no_mask = varOutput_seg[index != 0, :, :, :]
            input = np.array(input)
            if args.test_time_augment == 'flip':
                input = input[0:-1:2]

            threshold=0.3
            varOutput_seg = (varOutput_seg>threshold)*varOutput_seg
            if args.save_fig:
                for it in range(input.shape[0]):
                    save_fig_with_check_dir(os.path.join(config.submit, df_val.iloc[it + start_index].patient_id,
                                                         "{}.png".format(it + start_index)), (varOutput_seg[it,0]*255).astype(np.uint8))
                    # _,contours, _ = cv2.findContours((varOutput_seg[it,0]*255).astype(np.uint8), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
                    # img_draw = cv2.drawContours(cv2.cvtColor((input[it,0]*255).astype(np.uint8), cv2.COLOR_GRAY2BGR), contours, -1, (255, 0, 0), thickness=2)
                    # _,contours, _ = cv2.findContours((target_seg[it,0]*255).astype(np.uint8), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
                    # img_draw = cv2.drawContours(img_draw, contours, -1, ( 0,0, 255), thickness=2)
                    # save_fig_with_check_dir(os.path.join(config.submit,df_val.iloc[it+start_index].patient_id,"{}.png".format(it+start_index)),img_draw)

            start_index+=input.shape[0]

            # without no mask
            without_no_mask_index = np.sum(np.reshape(target_seg, (target_seg.shape[0], -1)), 1)
            target_seg_wout_nomask = target_seg[without_no_mask_index != 0, ...]
            varOutput_seg_wout_nomask  = varOutput_seg[without_no_mask_index != 0, ...]
            without_nomask_count+=varOutput_seg_wout_nomask.shape[0]
            for it_thres in range(len(thresholds)):
                dice_score_all[it_thres]+=calc_dice_all(varOutput_seg>thresholds[it_thres],target_seg)*varOutput_seg.shape[0]
                jaccard_score_all[it_thres]+=calc_jaccard_all(varOutput_seg>thresholds[it_thres],target_seg)*varOutput_seg.shape[0]
                if varOutput_seg_wout_nomask.shape[0]==0:
                    continue
                dice_score_without_nomask[it_thres]+=calc_dice_all(varOutput_seg_wout_nomask>thresholds[it_thres],target_seg_wout_nomask)*varOutput_seg_wout_nomask.shape[0]
                jaccard_score_without_nomask[it_thres]+=calc_jaccard_all(varOutput_seg_wout_nomask>thresholds[it_thres],target_seg_wout_nomask)*varOutput_seg_wout_nomask.shape[0]

        print ('DICE SCORE:',max(dice_score_all)/len(df_val))
        print ('JACCARD SCORE:',max(jaccard_score_all)/len(df_val))
        print ('DICE SCORE without no mask:',max(dice_score_without_nomask)/without_nomask_count)
        print ('JACCARD SCORE without no mask:',max(jaccard_score_without_nomask)/without_nomask_count)







