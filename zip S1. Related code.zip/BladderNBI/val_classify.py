#coding=utf-8
import glob
import sys
import threading
sys.setrecursionlimit(100000)
threading.stack_size(0x2000000)
import random
import warnings
from utils.tools import *
from config_classify import DefaultConfigs
import numpy as np
from data.classify_dataset import LcpDataset
from tqdm import tqdm
from models.model import get_net
from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score

import argparse

# 1. set random seed
random.seed(2050)
np.random.seed(2050)
torch.manual_seed(2050)
torch.cuda.manual_seed_all(2050)

torch.backends.cudnn.benchmark = True
warnings.filterwarnings('ignore')

parser = argparse.ArgumentParser(description='Finetune models Test')
parser.add_argument('--model_type', '-m', help='type of model')
parser.add_argument('--task_type', help='type of model')
parser.add_argument('--cv_id', default='', type=str,
                    help='0-4,id of cv , default is none')
parser.add_argument('--gpuid', '-g', default='0', metavar='N',
                    help='gpu id used for training (default: 0)')
parser.add_argument('--tag', '-t', default='', help='tag used for save')
parser.add_argument('--model_path', '-p', default='best',help='path of model')
# parser.add_argument('--submit_file_name', '-s', default='',help='path of model')
parser.add_argument('--image_size','-imsize', default=512, type=int,help='image width and height')
parser.add_argument('--batch_size', '-bs', default=1, type=int, help='batch size')
parser.add_argument('--num_workers', '-work', default=5, type=int, help='batch size')
# parser.add_argument('--not_extract_feature', '-nofeature', action='store_true', help='if extract feature at the same time')
pool_function_names=['normal','mac','spoc','gem']
parser.add_argument('--pool_type', '-pp', metavar='POOL', default='normal', choices=pool_function_names,
                    help='pool options: ')
parser.add_argument('--tta_type', '-tta', metavar='TTA', default=None,
                    help='tta options: ')
parser.add_argument('--num_classes','-nc',type=int,default=2,choices=[2,3])
parser.add_argument('--test',type=str,default='val',help='test data path')

def val(test_loader, model, fold):
    # 3.1 confirm the model converted to cuda
    filenames, labels, submissions = [], [], []
    model.cuda()
    model.eval()
    acc = AverageMeter()
    #result_score = np.zeros((len(test_loader), 100))
    predict_list, target_list = [],[]
    os.system('rm -rf '+os.path.join(config.submit,'predict_error'))
    summary_all_file = []
    for i, data_item in enumerate(tqdm(test_loader)):
        if len(data_item) == 3:
            input, target,image_path = data_item
            images_med = None
        else:
            input, target,image_path, images_med = data_item
        input_size = input.size()
        sub_image_num_pre_Imaage = 1
        if len(input_size) == 5:
            bs, sub_image_num_pre_Imaage, c, h, w = input_size
            input = input.view(-1, c, h, w)
            if images_med is not None:
                bs, sub_image_num_pre_Imaage, c, h, w = input_size
                images_med = images_med.view(-1, c, h, w)
        with torch.no_grad():

            image_var = input.cuda(non_blocking=True)
            target = np.array(target)
            # print(image_var.max(),image_var.mean(),image_var.min())
            if images_med is None:
                y_pred = model(image_var)
            else:
                images_med = images_med.cuda(non_blocking=True)
                y_pred = model(image_var, images_med)
            # print(y_pred)
            y_Pred_softmax = y_pred.softmax(-1).cpu().data.numpy()
            # print(y_Pred_softmax)
            if sub_image_num_pre_Imaage!=1:
                y_Pred_softmax = np.reshape(y_Pred_softmax, (
                    int(y_Pred_softmax.shape[0] / sub_image_num_pre_Imaage), sub_image_num_pre_Imaage, y_Pred_softmax.shape[1]))
                y_Pred_softmax = np.average(y_Pred_softmax, axis=1)


            y_Pred_softmax_argmax = np.argmax(y_Pred_softmax,-1)
            predict_list.extend(y_Pred_softmax_argmax.tolist())
            target_list.extend(target.tolist())

            for it in range(len(image_path)):
                sub_img = image_path[it]
                summary_all_file.append(f'{sub_img},{y_Pred_softmax[it,1]},{y_Pred_softmax_argmax[it]},{target[it]},{int(y_Pred_softmax_argmax[it]==target[it])}')
                if y_Pred_softmax_argmax[it]!=target[it]:

                    img_save_to = os.path.join(config.submit,'predict_error',sub_img.split('DataSet/')[1])
                    os.makedirs(os.path.dirname(img_save_to),exist_ok=True)
                    os.system(f'cp "{sub_img}" "{img_save_to}"')


            acc_batch = accuracy_score(target, y_Pred_softmax_argmax)
            acc.update(acc_batch, input.size(0))
            print ('step{}/{}\t acc:{} acc.val:{}'.format(i,len(test_loader),acc_batch,acc.avg))
    acc_batch_all = accuracy_score(np.array(target_list), np.array(predict_list))
    print ('all batch acc:',acc_batch_all)


    for _ in summary_all_file:
        print(_)

# 4. main function
def main():
    fold = 0
    # 4.1 mkdirs
    if not os.path.exists(config.submit):
        os.makedirs(config.submit)

    model = get_net(config)
    model.cuda()
    input_df = config.val_df
    if args.test=='test':
        input_df = config.test_df
    test_gen = LcpDataset(input_df,augument=False,mode="test",config=config,medinsight='MedImageInsight' in config.model_name)
    test_loader = DataLoader(test_gen,config.batch_size,shuffle=False,pin_memory=True,num_workers=args.num_workers)

    model_path = model_input

    if not os.path.exists(model_path):
        if model_path=='best':
            best_model = glob.glob(config.best_models+'/*.tar')
            if len(best_model):
                model_path = best_model[0]
        else:
            model_path=os.path.join(config.weights,model_path)

    print('load model from:'+model_path)

    best_model = torch.load(model_path)
    model.load_state_dict(best_model["state_dict"])
    # print(model.state_dict())
    val(test_loader,model,fold)

if __name__ == "__main__":
    args = parser.parse_args()
    gpu_id = args.gpuid
    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpuid
    config = DefaultConfigs(args.model_type, args.task_type, tag=args.tag,fold=args.cv_id,
                            batch_size=args.batch_size,
                            img_height=args.image_size, img_width=args.image_size)

    # config.pretrain = args.pretrain
    config.pool_type = args.pool_type
    config.num_classes = args.num_classes
    config.tta_type = args.tta_type
    model_input = args.model_path

    main()
