import os

# import rxrx1_utils.rxrx.io as rio
import pandas as pd


def mkdir_with_check(dir_path):
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
        try:
            os.system('chmod 777 {}'.format(dir_path))
        except:
            pass


class BaseConfig():
    def __init__(self, base_dir, model_name,task_type,fold):
        # self.set_path(dataset_type='official')
        # self.sample_submit_file = "/disk/2/lichuanpeng/Project_Models/Kaggle/Cellular/dataset/metadata/sample_submission.csv"
        self.weights = base_dir + "/models"
        self.best_models = base_dir + "/best_models/"
        self.submit = base_dir + "/submit/"
        self.logs_dir = base_dir + '/logs'
        self.features_dir = base_dir + '/features/'
        self.submit_file = os.path.join(self.submit, '{}_submission.csv'.format(model_name))

        self.run_type = 'train'
        self.tta_type = ''
        mkdir_with_check(base_dir)
        mkdir_with_check(self.weights)
        mkdir_with_check(self.best_models)
        mkdir_with_check(self.submit)
        mkdir_with_check(self.logs_dir)
        mkdir_with_check(self.features_dir)
        if fold == 'all':
            self.train_df = pd.read_csv(
                f'/fdata/lichuanpeng/Research/PangGuangJing/training_files/{task_type}/train_fold0.txt')
            self.val_df = pd.read_csv(
                f'/fdata/lichuanpeng/Research/PangGuangJing/training_files/{task_type}/val_fold0.txt')
            self.train_df = pd.concat([self.train_df, self.val_df ])
        else:
            self.train_df = pd.read_csv(
                f'/fdata/lichuanpeng/Research/PangGuangJing/training_files/{task_type}/train_fold{fold}.txt')

            self.val_df = pd.read_csv(
                f'/fdata/lichuanpeng/Research/PangGuangJing/training_files/{task_type}/val_fold{fold}.txt')

        self.test_df = pd.read_csv(
            f'/fdata/lichuanpeng/Research/PangGuangJing/training_files/{task_type}/test.txt')


class DefaultConfigs(BaseConfig):
    def __init__(self, model_name, task_type, tag='',fold=0, lr=0.05, epoch=50, batch_size=60, img_width=256, img_height=256):
        self.model_name = model_name
        self.BASE_DIR = "/data/lichuanpeng/Research/PangGuangJing/Models/{}/{}/{}/fold_{}".format(task_type,self.model_name,
                                                                                                   tag if tag != '' else 'temp',fold)
        BaseConfig.__init__(self, self.BASE_DIR, self.model_name,task_type,fold)

        self.num_classes = 2
        self.channels = 3
        self.lr = lr
        self.batch_size = batch_size
        self.epochs = epoch
        self.img_height = img_height
        self.img_width = img_width


def get_config(model_name, tag='', lr=0.05, epoch=50, batch_size=60):
    return DefaultConfigs(model_name, tag, lr, epoch, batch_size)
