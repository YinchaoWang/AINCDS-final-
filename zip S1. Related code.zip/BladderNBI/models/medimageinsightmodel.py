"""Medical Image Classification model wrapper class that loads the model, preprocesses inputs and performs inference."""
import os
import numpy as np
import cv2
import timm
import os
from PIL import Image
import torch
from  torch import nn
import torch.nn.functional as F
try:
    from .MedImageInsight.UniCLModel import build_unicl_model
    from .MedImageInsight.Utils.Arguments import load_opt_from_config_files
    from .MedImageInsight.ImageDataLoader import build_transforms
    from .MedImageInsight.LangEncoder import build_tokenizer
except:
    from MedImageInsight.UniCLModel import build_unicl_model
    from MedImageInsight.Utils.Arguments import load_opt_from_config_files
    from MedImageInsight.ImageDataLoader import build_transforms
    from MedImageInsight.LangEncoder import build_tokenizer
import torchvision.transforms as T


def mac(x):
    return F.max_pool2d(x, (x.size(-2), x.size(-1)))
    # return F.adaptive_max_pool2d(x, (1,1)) # alternative


def spoc(x):
    return F.avg_pool2d(x, ( x.size(-2), x.size(-1)))


def gem(x, p=3, eps=1e-6):
    return F.avg_pool2d(x.clamp(min=eps).pow(p), ( x.size(-2), x.size(-1))).pow(1. / p)

class MedImageInsight:
    """Wrapper class for medical image classification model."""

    def __init__(self, model_dir="/data/lichuanpeng/BigModel/PreTrain/MedImageInsights/2024.09.27",
                 vision_model_name="medimageinsigt-v1.0.0.pt", language_model_name="language_model.pth") -> None:

        """Initialize the medical image classifier.

        Args:
            model_dir: Directory containing model files and config
            vision_model_name: Name of the vision model
            language_model_name: Name of the language model
        """
        self.model_dir = model_dir
        self.vision_model_name = vision_model_name
        self.language_model_name = language_model_name
        self.model = None
        self.device = None
        self.tokenize = None
        self.preprocess = None
        self.opt = None
        self.load_model()

        self.proprecess_lcp = T.Compose([
            T.Resize((480, 480), interpolation=T.InterpolationMode.BICUBIC),
            T.ToTensor(),
            T.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            ),
        ])

    def load_model(self) -> None:
        """Load the model and necessary components."""
        try:
            # Load configuration
            config_path = os.path.join(self.model_dir, 'config.yaml')
            self.opt = load_opt_from_config_files([config_path])

            # Set paths
            self.opt['LANG_ENCODER']['PRETRAINED_TOKENIZER'] = os.path.join(
                self.model_dir,
                'language_model',
                'clip_tokenizer_4.16.2'
            )
            self.opt['UNICL_MODEL']['PRETRAINED'] = os.path.join(
                self.model_dir,
                'vision_model',
                self.vision_model_name
            )

            # Initialize components
            self.preprocess = build_transforms(self.opt, False)
            self.model = build_unicl_model(self.opt)

            # Set device
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            self.model.to(self.device)

            # Load tokenizer
            self.tokenize = build_tokenizer(self.opt['LANG_ENCODER'])
            self.max_length = self.opt['LANG_ENCODER']['CONTEXT_LENGTH']

            print(f"Model loaded successfully on device: {self.device}")

        except Exception as e:
            print("Failed to load the model:")
            raise e

    def encode(self, image_rgb):
        pil_image = Image.fromarray(image_rgb, mode='RGB')
        images = torch.stack([self.preprocess(pil_image)]).to(self.device)
        with torch.no_grad():
            image_embeddings = self.model.encode_image(images).cpu().numpy()
        return image_embeddings

    def forward(self,images):
        images = images[:,[2,1,0],...]
        images*=255.0
        # 调整通道顺序为 (H, W, C) 并转换为 NumPy 数组
        images = images.permute(0, 2, 3, 1).cpu().numpy()

        processed_images = []
        for img in images:
            pil_image = Image.fromarray(img.astype(np.uint8), mode='RGB')  # 转为 PIL 图像
            processed_image = self.proprecess_lcp(pil_image)  # 应用预处理
            processed_images.append(processed_image)

        # 将预处理后的图像堆叠成张量
        images_tensor = torch.stack(processed_images).to(self.device)
        print(images_tensor.shape)
        with torch.no_grad():
            image_embeddings = self.model.encode_image(images_tensor)
        return image_embeddings

class MedImageInsightFC(nn.Module):
    def __init__(self,num_classes=2):
        super(MedImageInsightFC,self).__init__()
        self.model = MedImageInsight()
        # self.head = nn.Linear(768, num_classes) if num_classes > 0 else nn.Identity()
        self.head = nn.Sequential(
            # nn.BatchNorm1d(1024),
            nn.Dropout(0.5),
            nn.Linear(1024, 128),
            # nn.ReLU(),
            nn.Dropout(0.5),  # 可选：加一个dropout层防止过拟合
            nn.Linear(128, num_classes)  # 最后一层：64 -> 2 (对应两个类别)
        )

    def forward(self, images, images_med):
        with torch.no_grad():
            feature = self.model.model.encode_image(images_med)
        x = self.head(feature)
        return x

class TimmMedImageInsightFC(nn.Module):
    def __init__(self, model_name, num_classes):
        super().__init__()
        self.timm_model = timm.create_model(model_name, pretrained=True, num_classes=num_classes, drop_rate=0.5)
        in_features = self.timm_model.get_classifier().in_features

        # 替换最后一层为包含两层的全连接结构
        self.timm_model_fc = nn.Sequential(
            nn.BatchNorm1d(in_features),
            nn.Dropout(0.5),
            nn.Linear(in_features, 64)
        )

        self.med_insight_model = MedImageInsight()
        self.med_insight_head = nn.Sequential(
            nn.BatchNorm1d(1024),
            nn.Dropout(0.5),
            nn.Linear(1024, 64)
        )

        self.out_fc = nn.Sequential(
            nn.BatchNorm1d(128),
            nn.Dropout(0.5),
            nn.Linear(128, num_classes)
        )

    def forward(self,images, images_med):
        time_features= self.timm_model.forward_features(images)
        time_features = gem(time_features)
        time_features = time_features.view(time_features.size(0), -1)
        time_features = self.timm_model_fc(time_features)
        with torch.no_grad():
            med_insight_features = self.med_insight_model.model.encode_image(images_med)

        med_insight_features = self.med_insight_head(med_insight_features)
        cat_features = torch.cat((time_features, med_insight_features), dim=1)
        return  self.out_fc(cat_features)



class TimmMedImageInsightFC2(nn.Module):
    def __init__(self, model_name, num_classes):
        super().__init__()
        self.timm_model = timm.create_model(model_name, pretrained=True, num_classes=num_classes, drop_rate=0.5)
        in_features = self.timm_model.get_classifier().in_features

        # 替换最后一层为包含两层的全连接结构
        self.timm_model_fc = nn.Sequential(
            nn.BatchNorm1d(in_features),
            nn.Dropout(0.5),
            nn.Linear(in_features, 64)
        )

        self.med_insight_model = MedImageInsight()
        self.med_insight_head = nn.Sequential(
            nn.BatchNorm1d(1024),
            nn.Dropout(0.5),
            nn.Linear(1024, 64)
        )

        # self.attention = nn.Linear(64 * 2, 2)  # 注意力模块
        self.out_fc = nn.Sequential(
            # nn.BatchNorm1d(64),
            nn.Dropout(0.5),
            nn.Linear(128, num_classes)
        )

    def forward(self,images, images_med):
        time_features= self.timm_model.forward_features(images)
        time_features = gem(time_features)
        time_features = time_features.view(time_features.size(0), -1)
        time_features = self.timm_model_fc(time_features)
        with torch.no_grad():
            med_insight_features = self.med_insight_model.model.encode_image(images_med)

        med_insight_features = self.med_insight_head(med_insight_features)

        med_insight_features = F.normalize(med_insight_features, dim=1)
        time_features = F.normalize(time_features, dim=1)
        cat_features = torch.cat((time_features, med_insight_features), dim=1)


        return self.out_fc(cat_features)




if __name__ == '__main__':

    # model = MedImageInsight()
    img = cv2.imread('/mnt/NAS/Research/PangGuangJing/各中心数据/齐鲁医院/恶性/BC/201804231771张新君BC/11071943.png')
    img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
    img = cv2.resize(img,(224,224))
    # im_encode = model.encode(img)
    # print(im_encode.shape)

    # model.proprecess_lcp(img)
    img = torch.from_numpy((img/255.0).astype(np.float32))
    img = img.transpose(0, 1).transpose(0, 2).contiguous()
    img_input = torch.stack([img]).cuda()
    # model =  MedImageInsightFC()
    model =  TimmMedImageInsightFC2("efficientnet_b4",2)
    model.cuda()
    model.eval()
    print(model(img_input,img_input).shape)


