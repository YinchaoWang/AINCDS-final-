# coding=utf-8
import timm

from .medimageinsightmodel import MedImageInsightFC, TimmMedImageInsightFC, TimmMedImageInsightFC2




def get_net(config):
    print('****************** Use {} ******************'.format(config.model_name))
    if timm.is_model(config.model_name):
        return timm.create_model(config.model_name, pretrained=True, num_classes=config.num_classes,drop_rate=0.5)
    elif config.model_name=='MedImageInsightFC':
        return MedImageInsightFC(config.num_classes)
    elif 'TimmMedImageInsightFC2' in config.model_name:
        timm_model_name = config.model_name[config.model_name.index('_')+1:]
        return TimmMedImageInsightFC2(timm_model_name,config.num_classes)
    elif 'TimmMedImageInsightFC' in config.model_name:
        timm_model_name = config.model_name[config.model_name.index('_')+1:]
        return TimmMedImageInsightFC(timm_model_name,config.num_classes)
    else:
        print('Error model {} not found!'.format(config.model_name))
        sys.exit('0')


if __name__ == '__main__1':
    pass
    import sys

    sys.path.append('../')
    from config import DefaultConfigs

    config = DefaultConfigs('EndoViT')
    config.set_path()
    # from thop import profile
    model = get_net(config)
    # print(profile(model, input_size=(1, 4, 800, 800)))
    params = list(model.parameters())
    k = 0
    for i in params:
        l = 1
        print("该层的结构：" + str(list(i.size())))
        for j in i.size():
            l *= j
        print("该层参数和：" + str(l))
        k = k + l
    print("总参数数量和：" + str(k / 1024 / 1024))
    ##################################


if __name__ == '__main__':
    model=  timm.create_model('resnet50', pretrained=True, num_classes=2, pretrained_cfg_overlay=dict(hf_hub_id=""))
    print(model)