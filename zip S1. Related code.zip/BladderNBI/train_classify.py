# coding=utf-8
# recurse in greedy thread
import sys
import threading

sys.setrecursionlimit(100000)
threading.stack_size(0x2000000)
import torch.multiprocessing

torch.multiprocessing.set_sharing_strategy('file_system')
import time
import math
import random
import warnings

USE_TENSORBOARD = True
if USE_TENSORBOARD:
    try:
        from tensorboardX import SummaryWriter
    except:
        USE_TENSORBOARD = False
from utils.tools import *
from data.classify_dataset import LcpDataset
from models.model import *
from torch import nn
import torch.backends.cudnn as cudnn
from torch.utils.data import DataLoader
from torch.optim import lr_scheduler
from timeit import default_timer as timer
from sklearn.metrics import accuracy_score
from torch.utils.data.sampler import WeightedRandomSampler
from config import DefaultConfigs
from collections import Counter
# from test_features import test
# from DataSet.dataset_config import TRAIN_EXPRIMENT_LIST,TEST_EXPRIMENT_LIST

# 1. set random seed
random.seed(2050)
np.random.seed(2050)
torch.manual_seed(2050)
torch.cuda.manual_seed_all(2050)
torch.backends.cudnn.benchmark = True
warnings.filterwarnings('ignore')
import argparse

loss_function_names = ['bce',  # BCEWithLogitsLoss
                       'focal',  # Focal Loss
                       'mlsm',  # MultiLabelSoftMarginLoss
                       'cel',  # CrossEntropyLoss
                       'focal_cel'
                       ]

optimizer_names = ['sgd', 'adam', 'rms']
lr_scheduler_names = ['step', 'exp', 'mstep', 'mstep']

parser = argparse.ArgumentParser(description='google landmark recongnition')
parser.add_argument('--model_type', '-m', help='type of model')
parser.add_argument('--task_type', help='type of model')
parser.add_argument('--tag', '-t', default='', help='tag used for save')
parser.add_argument('--gpuid', '-g', default='0', metavar='N',
                    help='gpu id used for training (default: 0)')

parser.add_argument('--epochs', '-e', default=50, type=int, metavar='N',
                    help='number of total epochs to run (default: 100)')

parser.add_argument('--learning_rate', '-lr', default=0.05, type=float,
                    metavar='LR', help='initial learning rate (default: 1e-6)')

parser.add_argument('--lr_gamma', default=0.5, type=float)
parser.add_argument('--use_weighted_samper', action='store_true',
                    help='if use WeightedRandomSampler')
parser.add_argument('--loss_type', '-lp', metavar='LOSS', default='cel', choices=loss_function_names,
                    help='loss options: ')

parser.add_argument('--lr_scheduler', '-lrs', default='step', choices=lr_scheduler_names,
                    help='lr_scheduler options: ')

parser.add_argument('--resume', default='', type=str, metavar='FILENAME',
                    help='name of the latest checkpoint (default: None)')
parser.add_argument('--pretrain', default='', type=str,
                    help='model path for pretrain')

parser.add_argument('--optimizer', '-o', metavar='OPTIMIZER', default='sgd',
                    choices=optimizer_names,
                    help='optimizer options: ' +
                         ' | '.join(optimizer_names) +
                         ' (default: adam)')
parser.add_argument('--cross_val', '-cv', action='store_true',
                    help='if use cross validation,flod is 5')
parser.add_argument('--cv_id', default='', type=str,
                    help='0-4,id of cv , default is none')
parser.add_argument('--cv_random_seed', '-cvrs', default=2050, type=int, help='random seed for cross validation')
parser.add_argument('--image_size', '-imsize', default=512, type=int, help='image width and height')
parser.add_argument('--batch_size', '-bs', default=64, type=int, help='batch size')
parser.add_argument('--num_workers', '-work', default=3, type=int, help='batch size')
parser.add_argument('--save_checkpoint_epoch', default=1, type=int, help='batch size')

parser.add_argument('--lr_mstep_milestones', default='20,30,40,50', type=str,
                    help='lr_scheduler options: ')
parser.add_argument('--num_classes', '-nc', default=2,type=int)


def train(train_loader, model, criterion, optimizer, epoch, valid_loss, best_results, start, fold):
    losses = AverageMeter()
    acc = AverageMeter()
    model.train()

    for i, data_item in enumerate(train_loader):
        if len(data_item)==2:
            images, target = data_item
            images_med = None
        else:
            images, target, images_med = data_item
        # if i>30:return [losses.avg, acc.avg]
        if images.size()[0] <= 1:
            print('skip single image this batch！')
            continue
        if config.multi_gpu:
            print('move to device')
            DEVICE = torch.device("cuda:0")
            images = images.to(DEVICE)
            target = torch.from_numpy(np.array(target)).to(DEVICE)
        else:
            images = images.cuda(non_blocking=True)
            target = torch.from_numpy(np.array(target)).cuda(non_blocking=True)
        if images_med is None:
            output = model(images)
        else:
            images_med = images_med.cuda(non_blocking=True)
            output = model(images,images_med)
        loss = criterion(output, target)
        optimizer.zero_grad()
        loss.backward()
        if config.multi_gpu:
            optimizer.module.step()
        else:
            optimizer.step()

        if i % 20 == 0:
            losses.update(loss.item(), images.size(0))
            y_pred = np.argmax(output.softmax(-1).cpu().data.numpy(), -1)
            acc_batch = accuracy_score(target.cpu().data.numpy(), y_pred)
            acc.update(acc_batch, images.size(0))
            message = '[train] fold:%d epoch:%d step:%d/%d\t（train loss:%0.6f score:%0.6f）\t（val loss:%0.6f score:%0.6f）\t（best %s  %s）\ttime ->%s' % ( \
                fold, epoch, i, len(train_loader),
                losses.avg, acc.avg,
                valid_loss[0], valid_loss[1],
                str(best_results[0])[:8], str(best_results[1])[:8],
                time_to_str((timer() - start), 'min'))
            # summary_writer.add_scalar('train_step/loss', losses.val, epoch*len(train_loader)+i)
            # summary_writer.add_scalar('train_step/acc', acc.val, epoch*len(train_loader)+i)
            # print message
            log.write(message)
            log.write("\n")
        # if (i+1)%2000==0 or (i+1)==len(train_loader):
        #     save_massage = save_checkpoint({
        #         "epoch": epoch + 1,
        #         "model_name": config.model_name,
        #         "state_dict": model.state_dict(),
        #         "best_loss": best_results[0],
        #         "optimizer": optimizer.module.state_dict() if config.multi_gpu else optimizer.state_dict(),
        #         "fold": fold,
        #         "best_acc": best_results[1],
        #     }, False, False, fold, epoch, config)
        #     log.write(save_massage)

    if USE_TENSORBOARD:
        summary_writer.add_scalar('train/loss-{}'.format(args.cv_id), losses.avg, epoch)
        summary_writer.add_scalar('train/accuracy-{}'.format(args.cv_id), acc.avg, epoch)
    log.write("\n")

    return [losses.avg, acc.avg]


# 2. evaluate fuunction
def evaluate(val_loader, model, criterion, epoch, train_loss, best_results, start, fold):
    losses = AverageMeter()
    acc = AverageMeter()
    # switch mode for evaluation
    # model.cuda()
    model.eval()
    with torch.no_grad():
        for i, data_item in enumerate(val_loader):
            if len(data_item) == 2:
                images, target = data_item
                images_med = None
            else:
                images, target, images_med = data_item
            if config.multi_gpu:
                DEVICE = torch.device("cuda:0")
                images_var = images.to(DEVICE)
                target = torch.from_numpy(np.array(target)).to(DEVICE)
            else:
                images_var = images.cuda(non_blocking=True)
                target = torch.from_numpy(np.array(target)).cuda(non_blocking=True)
            # target = torch.from_numpy(np.array(target)).cuda(non_blocking=True)
            if images_med is None:
                output = model(images_var)
            else:
                images_med = images_med.cuda(non_blocking=True)
                output = model(images_var, images_med)

            loss = criterion(output, target)
            losses.update(loss.item(), images_var.size(0))
            y_pred = np.argmax(output.softmax(-1).cpu().data.numpy(), -1)
            acc_batch = accuracy_score(target.cpu().data.numpy(), y_pred)
            acc.update(acc_batch, images_var.size(0))
            message = '[val] fold:%d  epoch:%d step:%d/%d\t（train loss:%0.3f score:%0.3f）\t（val loss:%0.3f score:%0.3f）\t（best %s  %s）\ttime ->%s' % ( \
                fold, epoch, i, len(val_loader),
                train_loss[0], train_loss[1],
                losses.avg, acc.avg,
                str(best_results[0])[:8], str(best_results[1])[:8],
                time_to_str((timer() - start), 'min'))

            log.write(message)
            log.write("\n")

        log.write("\n")
        # log.write(message)
        # log.write("\n")
    if USE_TENSORBOARD:
        summary_writer.add_scalar('val/loss-{}'.format(args.cv_id), losses.avg, epoch)
        summary_writer.add_scalar('val/accuracy-{}'.format(args.cv_id), acc.avg, epoch)
    return [losses.avg, acc.avg]


# 4. main function

def do_train(train_data_df, val_data_df,test_data_df, fold=0):
    # 4.2 get model
    model = get_net(config)

    device_ids = args.gpuid.split(',')
    print('DEVICES : ', device_ids)

    if len(device_ids) > 1:
        config.multi_gpu = True
        cudnn.benchmark = True
        model = nn.DataParallel(model, device_ids=[_ for _ in range(len(device_ids))])
        model = model.to(torch.device("cuda:0"))
    else:
        config.multi_gpu = False
        model.cuda()

    if config.pretrain:
        print('>>>>>>>[pretrain]:model:{}'.format(config.pretrain))
        assert os.path.exists(config.pretrain), 'Error pretrain model not found!'
        finetune_model = torch.load(args.pretrain, map_location='cpu')
        finetune_model_for_load = {}
        try:
            model.load_state_dict(finetune_model_for_load, strict=False)
        except:
            for it_ft_key in finetune_model["state_dict"]:
                if not it_ft_key.startswith('last_linear'):
                    finetune_model_for_load[it_ft_key] = finetune_model["state_dict"][it_ft_key]
            model.load_state_dict(finetune_model_for_load, strict=False)
        torch.cuda.empty_cache()
    # criterion
    optimizer = None
    if args.optimizer == 'sgd':
        print('>>>>>>[Optimizer]-->sgd')
        optimizer = torch.optim.SGD(model.parameters(), config.lr, momentum=0.9, weight_decay=1e-4)
    elif args.optimizer == 'adam':
        print('>>>>>>[Optimizer]-->adam')
        optimizer = torch.optim.Adam(model.parameters(), config.lr, weight_decay=1e-4)
    elif args.optimizer == 'rms':
        optimizer = torch.optim.RMSprop(model.parameters(), config.lr, momentum=0.9, weight_decay=1e-4)

    if config.multi_gpu:
        optimizer = nn.DataParallel(optimizer, device_ids=[_ for _ in range(len(device_ids))])

    if args.loss_type == 'bce':
        print('>>>>>>[Loss Type]:  BCEWithLogitsLoss  <<<<<<<')
        criterion = nn.BCEWithLogitsLoss().cuda()
    elif args.loss_type == 'focal':
        print('>>>>>>[Loss Type]:  FocalLoss  <<<<<<<')
        criterion = FocalLoss().cuda()
    elif args.loss_type == 'focal_cel':
        print('>>>>>>[Loss Type]:  FocalLoss + CrossEntropyLoss <<<<<<<')
        criterion = Focal_CEL().cuda()
    elif args.loss_type == 'cel':
        print('>>>>>>[Loss Type]:  CrossEntropyLoss  <<<<<<<')
        criterion = nn.CrossEntropyLoss().cuda()
    best_results = [0, 0]
    val_metrics = [0, 0]

    # load dataset

    train_gen = LcpDataset(train_data_df, augument=True, mode="train", config=config,medinsight='MedImageInsight' in config.model_name)
    ## WeightedRandomSampler ##
    if config.use_weighted_samper:
        print('Do weighted random sampler')
        # sample_weight = weighted_random_sampler(train_data_df, config)
        # sample_weight = np.ones(len(train_gen))
        labels = train_data_df['label'].values
        class_counts = Counter(labels)
        class_weights = {cls: 1.0 / count for cls, count in class_counts.items()}
        print('class_weights:',class_weights)
        # sample_weight[train_gen == 0] = 2  # 给label==2的加强采样
        sample_weight = np.array([class_weights[label] for label in labels])
        sampler = WeightedRandomSampler(sample_weight, num_samples=len(sample_weight),
                                        replacement=True)  # num_samples:一个epoch取多少样本
        train_loader = DataLoader(train_gen, batch_size=config.batch_size, pin_memory=True, sampler=sampler,
                                  num_workers=args.num_workers)
    else:
        train_loader = DataLoader(train_gen, batch_size=config.batch_size, shuffle=True, pin_memory=True,
                                  num_workers=args.num_workers)

    if val_data_df is not None and len(val_data_df) > 0:
        val_gen = LcpDataset(val_data_df, augument=False, mode="train", config=config,medinsight='MedImageInsight' in config.model_name)
        val_loader = DataLoader(val_gen, batch_size=config.batch_size, shuffle=False, pin_memory=True,
                                num_workers=args.num_workers)
    else:
        val_loader = None


    if test_data_df is not None and len(test_data_df) > 0:
        test_gen = LcpDataset(test_data_df, augument=False, mode="train", config=config,medinsight='MedImageInsight' in config.model_name)
        test_loader = DataLoader(test_gen, batch_size=config.batch_size, shuffle=False, pin_memory=True,
                                num_workers=args.num_workers)
    else:
        test_loader = None



    if args.lr_scheduler == 'step':
        print('>>>>>>[LR]-->StepLR')
        scheduler = lr_scheduler.StepLR(optimizer.module if config.multi_gpu else optimizer, step_size=8,
                                        gamma=args.lr_gamma)
    elif args.lr_scheduler == 'exp':
        print('>>>>>>[LR]-->ExponentialLR')
        scheduler = lr_scheduler.ExponentialLR(optimizer.module if config.multi_gpu else optimizer,
                                               gamma=0.9)
    elif args.lr_scheduler == 'mstep':
        print('>>>>>>[LR]-->ExponentialLR')
        scheduler = lr_scheduler.MultiStepLR(optimizer,
                                             milestones=[int(_) for _ in args.lr_mstep_milestones.split(',')],
                                             gamma=args.lr_gamma)
    start = timer()

    epoch_start = 0
    if args.resume:
        args.resume = os.path.join(config.weights, args.resume)
        if os.path.isfile(args.resume):
            print(">> Loading checkpoint:\n>> '{}'".format(args.resume))
            checkpoint = torch.load(args.resume)
            epoch_start = checkpoint['epoch']
            model.load_state_dict(checkpoint['state_dict'])
            optimizer.load_state_dict(checkpoint['optimizer'])
            best_results[0] = checkpoint['best_loss']
            best_results[1] = checkpoint['best_acc']
            fold = checkpoint['fold']
            print(">>>> loaded checkpoint:\n>>>> '{}' (epoch {})"
                  .format(args.resume, checkpoint['epoch']))
            if args.lr_scheduler == 'step':
                print('>>>>>>[Optimizer]-->sgd')
                scheduler = lr_scheduler.StepLR(optimizer, step_size=8,
                                                gamma=args.lr_gamma, last_epoch=epoch_start)
            elif args.lr_scheduler == 'exp':
                scheduler = lr_scheduler.ExponentialLR(optimizer, gamma=math.exp(-0.02), last_epoch=epoch_start)
            elif args.lr_scheduler == 'mstep':
                print('>>>>>>[LR]-->ExponentialLR')
                scheduler = lr_scheduler.MultiStepLR(optimizer,
                                                     milestones=[int(_) for _ in args.lr_mstep_milestones.split(',')],
                                                     gamma=args.lr_gamma)
        else:
            print(">> No checkpoint found at '{}'".format(args.resume))
            sys.exit(0)

    # train
    for epoch in range(epoch_start, config.epochs):
        scheduler.step(epoch)
        # train
        lr = get_learning_rate(optimizer.module if config.multi_gpu else optimizer)
        log.write('[Learning rate]:{}\n'.format(lr))
        if USE_TENSORBOARD:
            summary_writer.add_scalar('learning_rate', lr, epoch)
        print('--> train')
        train_metrics = train(train_loader, model, criterion, optimizer, epoch, val_metrics, best_results, start, fold)
        print('--> val')
        # val
        train_metrics = [0, 0]
        if not val_loader is None:
            val_metrics = evaluate(val_loader, model, criterion, epoch, train_metrics, best_results, start, fold)
        if not val_loader is None:
            test_metrics = evaluate(test_loader, model, criterion, epoch, train_metrics, best_results, start, fold)
        # check results
        is_best_loss = val_metrics[0] < best_results[0]
        best_results[0] = min(val_metrics[0], best_results[0])
        is_best_acc = val_metrics[1] > best_results[1]
        best_results[1] = max(val_metrics[1], best_results[1])
        print('save model')
        if epoch % args.save_checkpoint_epoch == 0 or is_best_acc:
            save_massage = save_checkpoint({
                "epoch": epoch + 1,
                "model_name": config.model_name,
                "state_dict": model.state_dict(),
                "best_loss": best_results[0],
                "optimizer": optimizer.module.state_dict() if config.multi_gpu else optimizer.state_dict(),
                "fold": fold,
                "best_acc": best_results[1],
            }, is_best_loss, is_best_acc, fold, epoch, config)
        # print logs
        log.write(save_massage)
        log.write('\n')
        message = '[best] fold%d epoch:%5.1f\t（train loss:%0.6f score:%0.6f）\t（val loss:%0.6f score:%0.6f）\t（best %s  %s）\ttime ->%s' % ( \
            fold, epoch,
            train_metrics[0], train_metrics[1],
            val_metrics[0], val_metrics[1],
            str(best_results[0])[:8], str(best_results[1])[:8],
            time_to_str((timer() - start), 'min'))
        # print message
        log.write(message)
        log.write("\n")

        time.sleep(0.01)

    best_model = torch.load(
        "%s/%s_fold_%s_model_best_loss.pth.tar" % (config.best_models, config.model_name, str(fold)))
    # best_model = torch.load("checkpoints/bninception_bcelog/0/checkpoint.pth.tar")
    model.load_state_dict(best_model["state_dict"])

    # test_gen = LcpDataset(config.test_df, augument=False, mode="test", config=config)
    # test_loader = DataLoader(test_gen, 1, shuffle=False, pin_memory=True, num_workers=args.num_workers)
    # test(test_loader, model, fold)


def list_intersect(a_list, b_list):
    """取交集"""
    return list((set(a_list).union(set(b_list))) ^ (set(a_list) ^ set(b_list)))


def main():
    do_train(config.train_df, config.val_df, config.test_df, 0)


if __name__ == "__main__":
    args = parser.parse_args()
    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpuid
    log = Logger()
    config = DefaultConfigs(args.model_type,args.task_type, tag=args.tag,fold=args.cv_id, lr=args.learning_rate, epoch=args.epochs,
                            batch_size=args.batch_size,
                            img_height=args.image_size, img_width=args.image_size)
    # USE_WEIGHTED_RANDOM_SAMPLER = args.use_weighted_samper
    config.use_weighted_samper = args.use_weighted_samper
    config.pretrain = args.pretrain
    config.num_classes = args.num_classes
    # config.save_param()
    if USE_TENSORBOARD:
        summary_writer = SummaryWriter(config.logs_dir)

    log.open("%s/%s_log_train_fold%s.txt" % (config.logs_dir, config.model_name, str(args.cv_id)), mode="a")
    main()
