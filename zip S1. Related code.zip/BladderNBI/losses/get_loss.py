#coding=utf-8
from torch import nn
from .combo import ComboLoss, ComboSuperVisionLoss
from .bce import StableBCELoss
from .dice import DiceLoss
from .focal import FocalLoss2d
from .jaccard import JaccardLoss

from .lovasz import LovaszLoss,LovaszLossSigmoid
from .dicebase_loss import FocalTversky_loss,AsymLoss,GDiceLossV2

class MutilLoss(nn.Module):
    def __init__(self,loss_type):
        super().__init__()
        self.loss_type=loss_type
        self.losses = {}
        for loss in loss_type:
            if loss =='StableBCELoss':
                self.losses[loss]=StableBCELoss()
            elif loss=='DiceLoss':
                self.losses[loss]=DiceLoss()
            elif loss=='FocalLoss2d':
                self.losses[loss]=FocalLoss2d()
            elif loss=='LovaszLoss':
                self.losses[loss]=LovaszLoss()
            elif loss=='FocalTversky':
                self.losses[loss]=FocalTversky_loss()
            elif loss=='AsymLoss':
                self.losses[loss]=AsymLoss()
            elif loss=='GDiceLossV2':
                self.losses[loss]=GDiceLossV2()
            elif loss=='CrossEntropyLoss':
                self.losses[loss]=nn.CrossEntropyLoss()



    def forward(self, input,target):
        loss_var = None
        for loss in self.losses:
            print(input.shape,target.shape)
            if loss_var is None:
                loss_var=self.losses[loss](input,target)*self.loss_type[loss]
            else:
                loss_var+=self.losses[loss](input,target)*self.loss_type[loss]
        return loss_var

