
import torch.utils.data as data
import torch
import numpy as np
import cv2
import pandas as pd
from torch.utils.data.sampler import  WeightedRandomSampler
from imgaug import augmenters as iaa


RESIZE_SIZE = 512
import os

IMAGE_BASE_PATH = ''



class ICH_Dataset(data.Dataset):

    def __init__(self, df = None, transform = None, tta = None):
        self.df = df
        self.transform = transform
        self.tta_type = tta

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        item = self.df.iloc[idx]
        image = cv2.imread(os.path.join(IMAGE_BASE_PATH,item.img_path))
        mask = cv2.imread(os.path.join(IMAGE_BASE_PATH,item.mask_path),0)

        if self.transform is not None:
            augmented = self.transform(image=image, mask=mask)
            # image = augmented['image'].transpose(2, 0, 1)

        image = augmented['image']
        if self.tta_type is not None:
            if self.tta_type == 'flip':
                new_X = np.zeros([2, image.shape[0], image.shape[1],3], image.dtype)
                new_X[0] = image
                new_X[1] = iaa.Fliplr(1).augment_image(image)
            image =  image.transpose(0,3, 1, 2)  #
        else:
            image =  image.transpose(2, 0, 1)  #


        mask = np.expand_dims(augmented['mask'], axis=0)
        mask[mask > 0.5] = 1
        image = torch.from_numpy(image).float().div(255)
        mask = torch.from_numpy(mask).float()
        # image = image.unsqueeze(0)
        return image, mask


def generate_dataset_loader(df_train,  train_transform, train_batch_size, df_val,val_transform, val_batch_size, workers):
    train_dataset = ICH_Dataset(df_train, train_transform)
    val_dataset = ICH_Dataset(df_val, val_transform)

    train_loader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=train_batch_size,        
        shuffle=True,
        num_workers=workers,
        pin_memory=True,
        drop_last=True)

    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=val_batch_size,        
        shuffle=False,
        num_workers=workers,
        pin_memory=True,
        # sampler=val_sampler,
        drop_last=False)

    return train_loader, val_loader

def generate_val_dataloader(df_val,val_transform, val_batch_size, workers,tta_type=None):
    val_dataset = ICH_Dataset(df_val, val_transform,tta_type)
    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=val_batch_size,
        shuffle=False,
        num_workers=workers,
        pin_memory=True,
        # sampler=val_sampler,
        drop_last=False)
    return val_loader


if __name__ == '__main__':
    from transformer import load_transformer
    df_train = pd.read_csv('/fdata/lichuanpeng/Research/PangGuangJing/training_files/seg_dataset/train_fold{}.csv'.format(0))
    df_val = pd.read_csv('/fdata/lichuanpeng/Research/PangGuangJing/training_files/seg_dataset/train_fold{}.csv'.format(0))
    tt,tv=load_transformer(512)
    train_loader,_=generate_dataset_loader(df_train,tt,5,df_val,tv,5,1)
    for i, (image,mask) in enumerate(train_loader) :
        image = image.numpy()
        mask = mask.numpy()
        print ('img',image.shape,image.dtype,np.max(image),np.min(image))
        print ('mask',mask.shape,mask.dtype,np.max(mask),np.min(mask))
        cv2.imwrite('/data/lichuanpeng/Temp/PangGuang/{}_img.png'.format(i),(image[2,0]*255).astype(np.uint8))
        cv2.imwrite('/data/lichuanpeng/Temp/PangGuang/{}_mask.png'.format(i),(mask[2,0]*255).astype(np.uint8))


