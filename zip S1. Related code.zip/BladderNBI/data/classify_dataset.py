from utils import *
from config import *
import torch
import cv2
from torch.utils.data import Dataset
from torchvision import transforms as T
from imgaug import augmenters as iaa
import random
import numpy as np
# set random seed
random.seed(2050)
np.random.seed(2050)
torch.manual_seed(2050)
torch.cuda.manual_seed_all(2050)
import sys


# GLOBAL_PIXEL_STATS = (np.array([0.485, 0.456, 0.406]),
#                        np.array([0.229, 0.224, 0.225]))

class LcpDataset(Dataset):
    def __init__(self, images_df,  augument=True, mode="train", config='',medinsight=False):
        self.config = config
        self.base_df = images_df.copy()
        self.images_df = images_df.copy()
        print(self.images_df.label.value_counts())
        self.augument = augument
        self.mode = mode
        self.medinsight = medinsight
        self.medinsight_preprocess = T.Compose([
            T.ToTensor(),
            T.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            ),
        ])


    def __len__(self):
        return len(self.images_df)

    def __getitem__(self, index):
        if not isinstance(index, int):
            index = index.item()
        X,Y = self.read_images(index)
        if self.augument:
            X = self.augumentor_new2(X)
        if self.medinsight:
            # X_med = cv2.resize(X,(480,480))
            X_med = cv2.cvtColor(X, cv2.COLOR_BGR2RGB)

            X_med = self.medinsight_preprocess(X_med)

        if self.config.tta_type == '':
            img = X/255.0
            img = torch.from_numpy(img)
            img = img.transpose(0, 1).transpose(0, 2).contiguous()
            if self.medinsight:
                return img.float(), Y, X_med
            return img.float(), Y
        else:
            # ------------ TTA ------------
            if self.config.tta_type == 'flip':
                new_X = np.zeros([4, X.shape[0], X.shape[1], X.shape[2]], X.dtype)
                new_X[0] = X
                new_X[1] = iaa.Fliplr(1).augment_image(X)
                new_X[2] = iaa.Flipud(1).augment_image(X)
                new_X[3] = iaa.Sequential([iaa.Fliplr(1), iaa.Flipud(1)]).augment_image(X)
            elif self.config.tta_type == 'fliprotate':
                new_X = np.zeros([8, X.shape[0], X.shape[1], X.shape[2]], X.dtype)
                new_X[0] = X
                new_X[1] = iaa.Fliplr(1).augment_image(X)
                new_X[2] = iaa.Flipud(1).augment_image(X)
                new_X[3] = iaa.Sequential([iaa.Fliplr(1), iaa.Flipud(1)]).augment_image(X)
                new_X[4] = iaa.Affine(rotate=270).augment_image(X)
                new_X[5] = iaa.Sequential([iaa.Fliplr(1), iaa.Affine(rotate=90)]).augment_image(X)
                new_X[6] = iaa.Sequential([iaa.Flipud(1), iaa.Affine(rotate=90)]).augment_image(X)
                new_X[7] = iaa.Affine(rotate=90).augment_image(X)
            elif self.config.tta_type == 'crop':
                crop_iaa = iaa.Crop(percent=(0, 0.1))
                repeat_times = 7
                new_X = np.zeros([repeat_times + 1, X.shape[0], X.shape[1], X.shape[2]], X.dtype)
                new_X[0] = X
                for i in range(repeat_times):
                    new_X[i + 1] = crop_iaa.augment_image(X)
            else:
                new_X = np.zeros([1, X.shape[0], X.shape[1], X.shape[2]], X.dtype)
                new_X[0] = X

            if self.medinsight:
                new_X_med=[]
                for _ in range(len(new_X)):
                    # X_med = cv2.resize(new_X[_],(480,480))
                    X_med = cv2.cvtColor(new_X[_], cv2.COLOR_BGR2RGB)
                    X_med = self.medinsight_preprocess(X_med)
                    new_X_med.append(X_med)
                new_X_med = torch.stack(new_X_med)

            img = new_X/255.0
            img = torch.from_numpy(img)
            img = img.transpose(1, 2).transpose(1, 3).contiguous()
            image_path = self.images_df.iloc[index].image
            if self.mode=='test':
                if self.medinsight:
                    return img.float(), Y, image_path, new_X_med
                return img.float(), Y,image_path
            if self.medinsight:
                return img.float(), Y, new_X_med
            return img.float(), Y

    def read_images(self, index):
        row = self.images_df.iloc[index]
        image = cv2.imread(row.image)
        label = int(row.label)
        if image is None:
            print(row.image+'not find')

        images = image.astype(np.uint8)
        # images = np.stack(images,-1)
        if self.config.img_height == images.shape[0] and self.config.img_width == images.shape[1]:
            return images,label
        else:
            return cv2.resize(images, (self.config.img_width, self.config.img_height)),label

    def augumentor(self, image):
        augment_img = iaa.Sequential([
            iaa.SomeOf((0, None), [
                iaa.Affine(shear=(-16, 16),rotate=(-20, 20)),
                iaa.Fliplr(0.5),
                iaa.GammaContrast((0.5, 2.0), per_channel=True),
                iaa.AddElementwise((-40, 40)),
                iaa.AdditiveGaussianNoise(scale=(0, 0.2 * 255)),
                iaa.Pepper(0.05),
                iaa.Crop(percent=(0, 0.2)),
            ])], random_order=True)

        image_aug = augment_img.augment_image(image)
        return image_aug


    def augumentor_new(self, image):
        augment_img = iaa.Sequential([
            iaa.SomeOf((0, 3), [  # 增加选择数量范围，提高增广多样性
                iaa.Affine(
                    scale=(0.8, 1.2),  # 增加缩放
                    shear=(-16, 16),
                    rotate=(-20, 20),
                    translate_percent={"x": (-0.1, 0.1), "y": (-0.1, 0.1)}  # 增加平移
                ),
                iaa.Fliplr(0.5),  # 水平翻转
                iaa.Flipud(0.5),  # 增加垂直翻转
                iaa.OneOf([
                    iaa.GammaContrast((0.5, 1.5), per_channel=False),
                    iaa.LinearContrast((0.5, 1.5), per_channel=False),  # 替换过时方法
                ]),
                iaa.OneOf([
                    iaa.AddElementwise((-10, 10)),
                    iaa.AdditiveGaussianNoise(scale=(0, 10)),
                    iaa.SaltAndPepper(0.02, per_channel=False),  # 添加椒盐噪声
                    iaa.GaussianBlur((0, 3.0)),
                    iaa.AverageBlur(k=(2, 4)),
                    iaa.MedianBlur(k=(3, 5)),
                    iaa.Sharpen(alpha=(0, 1.0), lightness=(0.75, 1.5)),
                ]),
                iaa.OneOf([
                    iaa.Multiply((0.8, 1.2), per_channel=True),  # 增强亮度变化
                    iaa.AddToHueAndSaturation((-20, 20)),  # 增加色相和饱和度变化
                ]),
                iaa.Crop(percent=(0, 0.1)),  # 随机裁剪
                iaa.PiecewiseAffine(scale=(0.01, 0.05)),  # 增加小范围形变
                iaa.ElasticTransformation(alpha=(0, 5.0), sigma=0.25)  # 增加弹性形变
            ])
        ], random_order=True)

        image_aug = augment_img.augment_image(image)
        return image_aug
    def augumentor_new2(self, image):

        augment_img = iaa.Sequential([
            iaa.SomeOf((1, 4), [
                # 几何变换
                iaa.Affine(
                    scale=(0.8, 1.2),
                    shear=(-16, 16),
                    rotate=(-20, 20),
                    translate_percent={"x": (-0.1, 0.1), "y": (-0.1, 0.1)}
                ),
                iaa.Fliplr(0.5),
                iaa.Flipud(0.5),

                # 对比度与锐化
                iaa.OneOf([
                    iaa.GammaContrast((1.2, 1.8), per_channel=False),
                    iaa.LinearContrast((0.8, 1.5), per_channel=False),
                    iaa.CLAHE(clip_limit=(1, 4)),
                    iaa.Sharpen(alpha=(0.3, 0.7), lightness=(0.8, 1.2)),
                ]),

                # 噪声与模糊
                iaa.OneOf([
                    iaa.AdditiveGaussianNoise(scale=(0, 15)),
                    iaa.SaltAndPepper(0.02, per_channel=False),
                    iaa.AverageBlur(k=(2, 4)),
                    iaa.MedianBlur(k=(3, 5)),
                    iaa.GaussianBlur((0, 3.0)),
                    iaa.ElasticTransformation(alpha=(0, 5.0), sigma=0.25),
                ]),

                # 颜色调整（重点限制范围）
                iaa.OneOf([
                    iaa.Multiply((0.8, 1.2), per_channel=True),
                    iaa.AddToHueAndSaturation((-20, 20)),  # 限制色相和饱和度变化范围
                ]),

                # 裁剪与小范围形变
                iaa.Crop(percent=(0, 0.1)),
                iaa.PiecewiseAffine(scale=(0.01, 0.05)),
            ])
        ], random_order=True)

        image_aug = augment_img.augment_image(image)
        return image_aug


if __name__ == '__main__':
    from config import DefaultConfigs
    config = DefaultConfigs('temp','LG_HG_pub')
    data = LcpDataset(config.train_df,config=config)
    from torch.utils.data import DataLoader
    val_loader = DataLoader(data, batch_size=1, shuffle=True, pin_memory=True,
                            num_workers=1)
    for i,it in enumerate(val_loader):
        image,label = it[0][0],it[1][0]

        image = (image.numpy().transpose((2,1,0))*255).astype(np.uint8)
        label = int(label)
        # cv2.imwrite(f'/home/lichuanpeng/temp/pangguangjing/{label}_{i}.jpg',image)



    # from torch.utils.data import DataLoader
    #
    # test_gen = LcpDataset(config.train_df, augument=False, mode="train", config=config)
    # test_loader = DataLoader(test_gen, 10, shuffle=False, pin_memory=True, num_workers=10)
    # for input,target in test_loader:
    #     print 'aaa'
    #     print input.size()
    #     print target



